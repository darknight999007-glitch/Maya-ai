package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MayaDao {

    // Tools
    @Query("SELECT * FROM tools ORDER BY category ASC, name ASC")
    fun getAllTools(): Flow<List<EntityTool>>

    @Query("SELECT * FROM tools WHERE category = :category ORDER BY name ASC")
    fun getToolsByCategory(category: String): Flow<List<EntityTool>>

    @Query("SELECT COUNT(*) FROM tools")
    suspend fun getToolCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTools(tools: List<EntityTool>)

    @Update
    suspend fun updateTool(tool: EntityTool)

    @Query("UPDATE tools SET isEnabled = :enabled WHERE id = :toolId")
    suspend fun setToolEnabled(toolId: String, enabled: Boolean)

    @Query("UPDATE tools SET isEnabled = :enabled WHERE category = :category")
    suspend fun setCategoryEnabled(category: String, enabled: Boolean)

    // Logs
    @Query("SELECT * FROM command_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllLogs(): Flow<List<EntityLog>>

    @Insert
    suspend fun insertLog(log: EntityLog)

    @Query("DELETE FROM command_logs")
    suspend fun clearLogs()

    // Memories
    @Query("SELECT * FROM memories ORDER BY id DESC")
    fun getAllMemories(): Flow<List<EntityMemory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: EntityMemory)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    // Macros
    @Query("SELECT * FROM macros ORDER BY id DESC")
    fun getAllMacros(): Flow<List<EntityMacro>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMacro(macro: EntityMacro)

    @Query("DELETE FROM macros WHERE id = :id")
    suspend fun deleteMacro(id: Long)

    // OTPs
    @Query("SELECT * FROM otps ORDER BY timestamp DESC")
    fun getAllOtps(): Flow<List<EntityOtp>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOtp(otp: EntityOtp)

    @Query("DELETE FROM otps")
    suspend fun clearOtps()
}
