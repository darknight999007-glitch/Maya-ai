package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tools")
data class EntityTool(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val description: String,
    val examplePrompt: String,
    val isEnabled: Boolean = true,
    val isCore: Boolean = false,
    val invocationCount: Int = 0
)

@Entity(tableName = "command_logs")
data class EntityLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val prompt: String,
    val response: String,
    val category: String,
    val agentUsed: String,
    val outcome: String
)

@Entity(tableName = "memories")
data class EntityMemory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val content: String,
    val dateAdded: String,
    val category: String
)

@Entity(tableName = "macros")
data class EntityMacro(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val triggerPhrase: String,
    val stepsDescription: String,
    val isScheduled: Boolean = false,
    val scheduleTime: String = "09:00 AM"
)

@Entity(tableName = "otps")
data class EntityOtp(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val code: String,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val syncedToDesktop: Boolean = true
)
