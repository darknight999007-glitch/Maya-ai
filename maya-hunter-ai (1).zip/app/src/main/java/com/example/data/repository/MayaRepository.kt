package com.example.data.repository

import com.example.data.local.EntityLog
import com.example.data.local.EntityMacro
import com.example.data.local.EntityMemory
import com.example.data.local.EntityOtp
import com.example.data.local.EntityTool
import com.example.data.local.MayaDao
import com.example.data.model.AgentFleetMember
import com.example.data.model.CategorySummary
import com.example.data.model.MayaPersona
import com.example.data.model.PhoneLinkStatus
import com.example.data.model.TimelineItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MayaRepository(private val dao: MayaDao) {

    private val scope = CoroutineScope(Dispatchers.IO)

    val allTools: Flow<List<EntityTool>> = dao.getAllTools()
    val allLogs: Flow<List<EntityLog>> = dao.getAllLogs()
    val allMemories: Flow<List<EntityMemory>> = dao.getAllMemories()
    val allMacros: Flow<List<EntityMacro>> = dao.getAllMacros()
    val allOtps: Flow<List<EntityOtp>> = dao.getAllOtps()

    private val _phoneLinkState = MutableStateFlow(PhoneLinkStatus())
    val phoneLinkState: StateFlow<PhoneLinkStatus> = _phoneLinkState.asStateFlow()

    private val _currentPersona = MutableStateFlow(MayaPersona.MAYA)
    val currentPersona: StateFlow<MayaPersona> = _currentPersona.asStateFlow()

    private val _agentFleet = MutableStateFlow(getInitialAgentFleet())
    val agentFleet: StateFlow<List<AgentFleetMember>> = _agentFleet.asStateFlow()

    init {
        scope.launch {
            if (dao.getToolCount() == 0) {
                dao.insertTools(DefaultToolsData.getInitialTools())
                seedInitialData()
            }
        }
    }

    private suspend fun seedInitialData() {
        // Initial memories
        dao.insertMemory(
            EntityMemory(
                key = "Editor Preference",
                content = "Prefers VS Code with dark theme and integrated bash terminal.",
                dateAdded = "Yesterday",
                category = "Developer"
            )
        )
        dao.insertMemory(
            EntityMemory(
                key = "Active Project",
                content = "Working on Maya 6.0 voice assistant companion app in ~/MayaProjects/companion.",
                dateAdded = "Today",
                category = "Projects"
            )
        )
        dao.insertMemory(
            EntityMemory(
                key = "Billing Routine",
                content = "Sends client invoices every Monday at 9:00 AM sharp.",
                dateAdded = "3 days ago",
                category = "Finance"
            )
        )

        // Initial macros
        dao.insertMacro(
            EntityMacro(
                title = "Morning Setup",
                triggerPhrase = "Run my morning setup macro",
                stepsDescription = "1. Open VS Code\\n2. Launch Chrome (GitHub & Docs)\\n3. Start Spotify Focus\\n4. Snap layout 50/50",
                isScheduled = true,
                scheduleTime = "09:00 AM"
            )
        )
        dao.insertMacro(
            EntityMacro(
                title = "Clean Build & Temp",
                triggerPhrase = "Clean temp files and caches",
                stepsDescription = "1. Purge %TEMP%\\n2. Clear Gradle daemon cache\\n3. Empty Recycle Bin safely",
                isScheduled = false
            )
        )

        // Initial OTPs synced from phone
        dao.insertOtp(
            EntityOtp(
                sender = "HDFC-BANK",
                code = "582914",
                messageText = "582914 is your OTP for transaction at Amazon. Valid for 10 mins. Do not share.",
                syncedToDesktop = true
            )
        )
        dao.insertOtp(
            EntityOtp(
                sender = "GOOGLE",
                code = "934201",
                messageText = "G-934201 is your Google verification code for Desktop Maya login.",
                syncedToDesktop = true
            )
        )
    }

    fun getCategories(): List<CategorySummary> = DefaultToolsData.categories

    fun getTimeline(): List<TimelineItem> = DefaultToolsData.defaultTimeline

    suspend fun setToolEnabled(toolId: String, enabled: Boolean) {
        dao.setToolEnabled(toolId, enabled)
    }

    suspend fun setCategoryEnabled(category: String, enabled: Boolean) {
        dao.setCategoryEnabled(category, enabled)
    }

    suspend fun addLog(prompt: String, response: String, category: String, agentUsed: String, outcome: String) {
        dao.insertLog(
            EntityLog(
                prompt = prompt,
                response = response,
                category = category,
                agentUsed = agentUsed,
                outcome = outcome
            )
        )
    }

    suspend fun addMemory(key: String, content: String, category: String) {
        dao.insertMemory(
            EntityMemory(
                key = key,
                content = content,
                dateAdded = "Just now",
                category = category
            )
        )
    }

    suspend fun deleteMemory(id: Long) {
        dao.deleteMemory(id)
    }

    suspend fun addMacro(title: String, triggerPhrase: String, steps: String) {
        dao.insertMacro(
            EntityMacro(
                title = title,
                triggerPhrase = triggerPhrase,
                stepsDescription = steps
            )
        )
    }

    suspend fun deleteMacro(id: Long) {
        dao.deleteMacro(id)
    }

    suspend fun receiveSimulatedOtp(sender: String, code: String, message: String) {
        dao.insertOtp(
            EntityOtp(
                sender = sender,
                code = code,
                messageText = message,
                syncedToDesktop = true
            )
        )
    }

    fun setPersona(persona: MayaPersona) {
        _currentPersona.value = persona
    }

    fun updatePhoneLink(status: PhoneLinkStatus) {
        _phoneLinkState.value = status
    }

    fun toggleDuetMode() {
        val current = _phoneLinkState.value
        _phoneLinkState.value = current.copy(isDuetModeActive = !current.isDuetModeActive)
    }

    fun toggleFlashlight() {
        val current = _phoneLinkState.value
        _phoneLinkState.value = current.copy(flashlightOn = !current.flashlightOn)
    }

    fun toggleVoiceCall() {
        val current = _phoneLinkState.value
        _phoneLinkState.value = current.copy(isVoiceCallActive = !current.isVoiceCallActive)
    }

    fun spawnNewAgentTask(name: String, mission: String, type: String) {
        val currentList = _agentFleet.value.toMutableList()
        val newAgent = AgentFleetMember(
            id = "agent_${System.currentTimeMillis()}",
            name = name,
            type = type,
            currentMission = mission,
            progress = 0.05f,
            status = "RUNNING",
            logs = listOf(
                "Task initialized by user on Android Companion",
                "Spawning sandboxed process on Windows Host",
                "Allocating toolchain: $type"
            ),
            engine = if (type == "Coding agent") "Claude Code" else "Hermes Sub-Agent"
        )
        currentList.add(0, newAgent)
        _agentFleet.value = currentList
    }

    fun simulateAgentProgress(agentId: String) {
        val currentList = _agentFleet.value.map { agent ->
            if (agent.id == agentId && agent.status == "RUNNING") {
                val newProgress = (agent.progress + 0.35f).coerceAtMost(1.0f)
                val newStatus = if (newProgress >= 1.0f) "COMPLETED" else "RUNNING"
                val extraLog = if (newProgress >= 1.0f) {
                    "Execution finished successfully with exit code 0."
                } else {
                    "Step executed. Analyzing output and intermediate state..."
                }
                agent.copy(
                    progress = newProgress,
                    status = newStatus,
                    logs = agent.logs + extraLog
                )
            } else agent
        }
        _agentFleet.value = currentList
    }

    fun generatePersonaResponse(prompt: String, persona: MayaPersona): String {
        val p = prompt.lowercase()
        return when (persona) {
            MayaPersona.MAYA -> {
                when {
                    p.contains("briefing") || p.contains("morning") ->
                        "Good morning! System health is nominal at 34°C, 3 unread emails, YouTube gained +340 subscribers overnight, and your Q3 report is waiting."
                    p.contains("otp") ->
                        "I've got the OTP from your phone: 582914. It's already in your Windows clipboard ready to paste!"
                    p.contains("code") || p.contains("flask") || p.contains("build") ->
                        "On it! Claude Code is writing the endpoints in ~/MayaProjects. I'll watch the terminal and interrupt you when tests pass."
                    p.contains("call") || p.contains("phone") ->
                        "Ringing your paired Android phone right now. You can talk directly through desktop speakers!"
                    p.contains("photo") || p.contains("whatsapp") ->
                        "WhatsApp opened. Matching contact, attaching file, and sending. Delivered!"
                    p.contains("macro") ->
                        "Running your macro right now. Opening apps and snapping your layout. Done before your coffee lands!"
                    p.contains("error") ->
                        "I read the error off the screen: missing import. I patched it and tests are green now."
                    p.contains("sleep") || p.contains("so jao") ->
                        "Goodnight! Offline wake word listener remains active at zero idle CPU. See you tomorrow."
                    else ->
                        "Got it! Executing '$prompt' across your Windows system right now."
                }
            }
            MayaPersona.FRIDAY -> {
                when {
                    p.contains("briefing") || p.contains("morning") ->
                        "Morning briefing ready, Hunter. All 234 tools active. CPU load 8%, GPU memory clear. 3 messages flagged for review."
                    p.contains("otp") ->
                        "OTP detected from phone link: 582914. Injected to host clipboard buffer."
                    p.contains("code") || p.contains("build") ->
                        "Dispatching task to Coding Agent runtime. Monitoring terminal standard output for errors."
                    p.contains("call") || p.contains("phone") ->
                        "Establishing direct VoIP bridge to paired handset over 192.168.1.104."
                    else ->
                        "Instruction confirmed: '$prompt'. Task routed to appropriate subsystem."
                }
            }
            MayaPersona.VENOM -> {
                when {
                    p.contains("briefing") || p.contains("morning") ->
                        "Awake already? Fine. Your computer is alive, people left you 3 useless emails, and your channel grew. Let's conquer something."
                    p.contains("otp") ->
                        "Snagged your OTP: 582914. It's pasted. Don't make us wait."
                    p.contains("code") || p.contains("build") ->
                        "We're writing the code ourselves. Any bug that appears will be destroyed in seconds."
                    p.contains("call") || p.contains("phone") ->
                        "Calling your noisy little pocket machine now. Answer it!"
                    else ->
                        "We heard you: '$prompt'. We are tearing through the Windows kernel to do it right now."
                }
            }
        }
    }

    private fun getInitialAgentFleet(): List<AgentFleetMember> {
        return listOf(
            AgentFleetMember(
                id = "agent_coding_1",
                name = "Claude Code Runner",
                type = "Coding agent",
                currentMission = "Scaffold Flask API with JWT auth & Dockerfile in ~/MayaProjects/auth-svc",
                progress = 0.85f,
                status = "RUNNING",
                logs = listOf(
                    "Initialized ~/MayaProjects/auth-svc/app.py",
                    "Wrote requirements.txt with flask, pyjwt, pytest",
                    "pytest ran: 8 passed, 0 failed in 0.42s",
                    "Preparing Dockerfile and docker-compose.yml"
                ),
                engine = "Claude Code (Visible Mode)"
            ),
            AgentFleetMember(
                id = "agent_research_1",
                name = "Deep Research Sub-Agent A",
                type = "Research agent",
                currentMission = "Competitor analysis: EV battery supply chain logistics & pricing",
                progress = 0.60f,
                status = "RUNNING",
                logs = listOf(
                    "Visited 14 academic and market research sources",
                    "Cross-checking battery chemistry patent filings",
                    "Drafting Section 3: Nickel vs LFP cost trajectories",
                    "Formatting Word document with Harvard citations"
                ),
                engine = "Hermes Sub-Agent"
            ),
            AgentFleetMember(
                id = "agent_browser_1",
                name = "Chrome Browser Agent",
                type = "Browser agent",
                currentMission = "Flight price comparison for Delhi next Friday",
                progress = 1.0f,
                status = "COMPLETED",
                logs = listOf(
                    "Attached to persistent Chrome window (logged in)",
                    "Queried 3 airlines for best non-stop departures",
                    "Found optimal flight: 6E-204 at ₹4,890 (08:30 AM)",
                    "Sent summary card to Maya HUD"
                ),
                engine = "Persistent Chrome CDP"
            ),
            AgentFleetMember(
                id = "agent_desktop_1",
                name = "Windows Automation Agent",
                type = "Desktop agent",
                currentMission = "Batch rename 180 photos in Downloads/ to trip-001.jpg format",
                progress = 1.0f,
                status = "COMPLETED",
                logs = listOf(
                    "Discovered 180 image files matching pattern",
                    "Generated sequential names trip-001 to trip-180",
                    "Safe rename executed without file conflict",
                    "Undo manifest preserved in .maya-undo"
                ),
                engine = "Native Win32 & PowerShell"
            )
        )
    }
}
