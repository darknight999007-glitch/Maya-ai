package com.example.data.repository

import com.example.data.local.EntityTool
import com.example.data.model.CategorySummary
import com.example.data.model.TimelineItem

object DefaultToolsData {

    val categories = listOf(
        CategorySummary("Core essentials", 68, "star", "System heart, reasoning, fuzzy resolver, and pipeline routing", true),
        CategorySummary("PC control", 25, "computer", "Direct Windows actions: apps, hotkeys, terminal, brightness", true),
        CategorySummary("Accessibility", 25, "accessibility", "Hands-free web & desktop control, click by number, tab switch", true),
        CategorySummary("Macros", 13, "bolt", "Record by doing, step replay, scheduling, export & share", true),
        CategorySummary("Documents", 12, "description", "Word, PDF, Excel generator, folder indexing, document agent", true),
        CategorySummary("Skills engine", 10, "auto_stories", "Self-authoring runtime, sandbox tester, version rollback", true),
        CategorySummary("YouTube", 9, "smart_display", "Search, playback, download track, auto-tag and publish video", true),
        CategorySummary("WhatsApp", 8, "chat", "Desktop messaging, folder attach, read aloud, voice calling", true),
        CategorySummary("Analytics", 8, "insights", "Hardware metrics, CPU/GPU throttling, YouTube subscriber mining", true),
        CategorySummary("Voice security", 8, "security", "Voiceprint match, guest sandbox, anti-spoofing, intrusion log", true),
        CategorySummary("Music", 8, "music_note", "Global media keys, taste profile, session queue, focus radio", true),
        CategorySummary("Study & whiteboard", 6, "draw", "Interactive screen canvas, equation renderer, export PNG", true),
        CategorySummary("Email", 4, "mail", "Inbox summarization, voice dictation, thread reply, spam purge", true),
        CategorySummary("Camera & vision", 4, "photo_camera", "Webcam scene description, facial recognition, photo trigger", true),
        CategorySummary("Screen recording", 4, "videocam", "Record display, pause, resume, instant replay buffer", true),
        CategorySummary("Clipboard", 3, "content_paste", "Deep clipboard history, voice search, spreadsheet paste-link", true),
        CategorySummary("Coding agent", 3, "terminal", "Scaffold stack, live VS Code watcher, self-healing loop", true),
        CategorySummary("Finance", 3, "trending_up", "Real-time stock ticker, price history readout, crypto watch", true),
        CategorySummary("Plugins", 3, "extension", "Drop-in Python plugins, marketplace hub, auto-reload", true),
        CategorySummary("Hermes agent", 3, "psychology", "Nous Research autonomous agent, shell sandbox, self-learning", true),
        CategorySummary("Expense tracker", 2, "receipt_long", "Parse bank/card/UPI receipts in inbox, itemized breakdown", true),
        CategorySummary("Weather & smart home", 2, "wb_sunny", "Location-based forecast & local ambient appliance control", true),
        CategorySummary("Live commentary", 2, "mic", "AI co-host roast & reaction to gameplays, coding & screen streams", true),
        CategorySummary("Support", 1, "help", "Diagnostics, log exporter, and one-click in-app update checker", true)
    )

    fun getInitialTools(): List<EntityTool> {
        val tools = mutableListOf<EntityTool>()

        // 1. Core essentials (68 tools)
        val coreExamples = listOf(
            "Natural speech reasoning engine", "16 kHz audio capture parser", "24 kHz voice synthesizer",
            "Barge-in interrupt detector", "Echo suppression filter", "Local plain-file memory",
            "Multi-model arbitration router", "Intent classifier", "Contextual pronoun resolver",
            "Cross-session thread restorer", "Fuzzy command matcher", "Latency optimizer",
            "Offline wake word listener", "Entity extractor", "Markdown to speech formatter",
            "JSON payload validator", "Token streaming pipeline", "Error self-recovery",
            "Multi-turn dialogue manager", "Dynamic parameter slot-filler"
        )
        for (i in 1..68) {
            val label = if (i <= coreExamples.size) coreExamples[i - 1] else "Core Pipeline Tool #$i"
            tools.add(
                EntityTool(
                    id = "core_$i",
                    name = label,
                    category = "Core essentials",
                    description = "Fundamental Maya 6.0 engine capability for speech, memory, and orchestration.",
                    examplePrompt = if (i == 1) "Maya, what are you currently processing?" else "Status check core subsystem $i",
                    isEnabled = true,
                    isCore = true
                )
            )
        }

        // 2. PC control (25 tools)
        val pcControlTools = listOf(
            Pair("Open App", "Open Photoshop and maximize it."),
            Pair("Close App", "Close all background browsers."),
            Pair("Minimize Windows", "Minimize everything except VS Code."),
            Pair("Show Desktop", "Show desktop immediately."),
            Pair("Scroll Window", "Scroll down 500 pixels."),
            Pair("Press Hotkey", "Press Ctrl+Shift+P."),
            Pair("Type Text", "Type 'import numpy as np' into focused app."),
            Pair("PowerShell Runner", "Run npm install in this folder."),
            Pair("Sleep PC", "Sleep the PC now."),
            Pair("Restart PC", "Restart Windows in safe mode."),
            Pair("Set Brightness", "Brightness 40, volume 20."),
            Pair("Set Volume", "Mute system audio."),
            Pair("Clean Temp Files", "Clean up temporary build files."),
            Pair("Window Snap Left", "Snap this window to the left half."),
            Pair("Window Snap Right", "Snap Chrome to the right half."),
            Pair("Focus App By Title", "Focus Spotify window."),
            Pair("Toggle Fullscreen", "Make current window fullscreen."),
            Pair("Send Alt+Tab", "Switch to the previous application."),
            Pair("Virtual Desktop Next", "Switch to virtual desktop 2."),
            Pair("Lock Workstation", "Lock the computer."),
            Pair("Task Manager Check", "Show processes taking highest memory."),
            Pair("Kill Stuck Process", "Kill the unresponsive node process."),
            Pair("Set Night Light", "Turn on Windows night light filter."),
            Pair("Change Audio Device", "Switch output to Sony Bluetooth Headphones."),
            Pair("HUD Corner Move", "Maya, move yourself to the bottom-left.")
        )
        pcControlTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "pc_control_${idx + 1}",
                    name = pair.first,
                    category = "PC control",
                    description = "Direct hardware and operating system control across Windows 10/11.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 3. Accessibility (25 tools - expanded in 6.0)
        val accessTools = listOf(
            Pair("Web Click Button", "Click the blue Sign In button."),
            Pair("Web Fill Form", "Fill the form: name Hunter, email mine, message hello."),
            Pair("Web Select Dropdown", "Select 'Standard Shipping' from delivery options."),
            Pair("Web Switch Tab", "What tabs do I have open? Switch to Gmail."),
            Pair("Web Close Tab", "Close current tab."),
            Pair("Web Scroll To Header", "Scroll down to pricing section."),
            Pair("Desktop Numbered Click", "Click number four."),
            Pair("Read Screen Text", "Read the screen aloud."),
            Pair("Drag Item To Bin", "Drag that file onto the Recycle Bin."),
            Pair("Move Cursor By Voice", "Move mouse to top right corner."),
            Pair("Voice Double Click", "Double click current item."),
            Pair("Right Click Context", "Right click on selected file."),
            Pair("OCR On-Screen Button", "Click the text 'Download Full Report'."),
            Pair("Dictation Mode Toggle", "Start continuous dictation in Word."),
            Pair("Magnify Region", "Zoom in 2x on chart area."),
            Pair("High Contrast Toggle", "Enable high contrast reading mode."),
            Pair("List Open Windows", "What windows are currently open?"),
            Pair("Read Focused Control", "What element has keyboard focus?"),
            Pair("Voice Scroll Up", "Scroll up one page."),
            Pair("Navigate Breadcrumbs", "Go up two folders in file explorer."),
            Pair("Simulate Drag & Drop", "Drag invoice.pdf to attachments area."),
            Pair("HUD Transparency Slider", "Make your HUD overlay 80% translucent."),
            Pair("HUD Hide / Show", "Maya hide your overlay."),
            Pair("Voice Wake Offline", "Hey Maya — wake up."),
            Pair("Voice Sleep Hands-Free", "So jao (Maya sleeps, 0 idle cost).")
        )
        accessTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "access_${idx + 1}",
                    name = pair.first,
                    category = "Accessibility",
                    description = "Hands-free computing for anyone who can't use a mouse or keyboard.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 4. Macros (13 tools)
        val macroTools = listOf(
            Pair("Record Action Macro", "Record a macro. ...Stop. Call it 'morning setup'."),
            Pair("Replay Macro", "Run my morning setup macro."),
            Pair("Schedule Macro Run", "Run morning setup every weekday at 9 a.m."),
            Pair("Edit Macro Step", "Change step 3 of morning setup to open Edge instead."),
            Pair("Duplicate Macro", "Duplicate 'nightly backup' to 'quick backup'."),
            Pair("Export Macro File", "Export morning setup as .maya-macro JSON."),
            Pair("Import Macro", "Import macro from Downloads/developer_pipeline.json."),
            Pair("List Saved Macros", "What macros do I have saved?"),
            Pair("Delete Macro", "Delete macro 'test run'."),
            Pair("Test Macro Dry-Run", "Dry run macro without executing file writes."),
            Pair("Share Macro To Cloud", "Share workflow macro with team."),
            Pair("Trigger On App Open", "When VS Code launches, trigger layout macro."),
            Pair("Macro Undo Last Step", "Undo previous macro action.")
        )
        macroTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "macro_${idx + 1}",
                    name = pair.first,
                    category = "Macros",
                    description = "Teach by doing: record once, replay anytime with voice commands.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 5. Documents (12 tools)
        val docTools = listOf(
            Pair("Create Word Doc", "Make me a two-page résumé from my LinkedIn facts."),
            Pair("Index Document Folder", "Index papers folder for semantic search."),
            Pair("Semantic Document Search", "Search my indexed papers for anything on CVD."),
            Pair("Export To PDF", "Export current document as PDF."),
            Pair("Excel Dashboard Generator", "Turn this sales sheet into a dashboard."),
            Pair("Document Agent Delegation", "Let document agent format the 50-page handbook."),
            Pair("Summarize Contract", "Read this contract's key points and liabilities."),
            Pair("Compare Two Documents", "Highlight differences between draft v1 and v2."),
            Pair("Batch OCR Folder", "OCR all scanned receipts in folder."),
            Pair("Auto-Format Citations", "Format all citations in IEEE format."),
            Pair("Translate Document", "Translate this technical manual to Bengali."),
            Pair("Extract Document Tables", "Extract all tables to a new Excel workbook.")
        )
        docTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "doc_${idx + 1}",
                    name = pair.first,
                    category = "Documents",
                    description = "Autonomous generation, indexing, and question-answering over local documents.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 6. Skills engine (10 tools)
        val skillTools = listOf(
            Pair("Self-Author New Skill", "Maya, learn to convert HEIC photos to JPEG."),
            Pair("Sandbox Test Skill", "Test new image converter in sandbox container."),
            Pair("Install Tested Skill", "Install the verified HEIC skill to active toolset."),
            Pair("Rollback Skill Version", "Roll back the git-helper skill to previous version."),
            Pair("Open Marketplace", "Show me the skill marketplace. Install the PDF one."),
            Pair("Install From GitHub Repo", "Install skill from github.com/user/maya-speech-enhancer."),
            Pair("Prompt Skill Builder", "Teach Maya how to review legal clauses like an IP lawyer."),
            Pair("Inspect Skill Code", "Show me the Python implementation of WhatsApp skill."),
            Pair("Disable Skill", "Disable experimental Spotify scrubber skill."),
            Pair("Skill Performance Telemetry", "Show execution times for all custom skills.")
        )
        skillTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "skill_${idx + 1}",
                    name = pair.first,
                    category = "Skills engine",
                    description = "Self-extending engine: Maya writes and installs new Python skills at runtime.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 7. YouTube (9 tools)
        val ytTools = listOf(
            Pair("Search & Play", "Play Lo-Fi chill beats on YouTube."),
            Pair("Skip Video", "Skip to next track."),
            Pair("Pause Playback", "Pause YouTube player."),
            Pair("Download Audio Track", "Download the current song as MP3."),
            Pair("Voice Video Upload", "Upload finished video with title Episode 12."),
            Pair("Generate Video Description", "Write SEO description and hashtags for podcast."),
            Pair("Set Video Tags", "Add tags: #Maya #AI #Tech to current draft."),
            Pair("Check Upload Status", "How much of Episode 12 is processed?"),
            Pair("Playlist Manager", "Add this video to my 'AI Research' playlist.")
        )
        ytTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "yt_${idx + 1}",
                    name = pair.first,
                    category = "YouTube",
                    description = "Full YouTube playback control and creator publishing suite.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 8. WhatsApp (8 tools)
        val waTools = listOf(
            Pair("Message Contact", "Send Mom yesterday's photos."),
            Pair("Attach File / Folder", "Send Priya the spec, and attach the PDF."),
            Pair("List Unread Messages", "Who messaged me? Read them."),
            Pair("Read Conversation Aloud", "Read the latest messages from Rohit."),
            Pair("Place WhatsApp Voice Call", "Call Dev on WhatsApp desktop."),
            Pair("Send Screen Snapshot", "Screenshot my current screen and send to design group."),
            Pair("Dictate Quick Reply", "Reply: I'll review it tonight."),
            Pair("Search Chat Media", "Find the invoice image sent last Tuesday.")
        )
        waTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "wa_${idx + 1}",
                    name = pair.first,
                    category = "WhatsApp",
                    description = "Hands-free communication directly into WhatsApp Desktop.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 9. Analytics (8 tools)
        val analyticsTools = listOf(
            Pair("Hardware Health Overview", "How's my system health?"),
            Pair("CPU & RAM Load Check", "Why is my PC slow right now?"),
            Pair("GPU Throttling Sensor", "Is my GPU thermal throttling in Blender?"),
            Pair("YouTube Subscriber Tally", "How many new subscribers overnight?"),
            Pair("Video View Velocity", "Show 24-hour view curve for yesterday's upload."),
            Pair("Comment Sentiment Mining", "Analyze audience sentiment from the last video."),
            Pair("Disk Space Breakdown", "What folders are consuming the most SSD space?"),
            Pair("Process Power Usage", "Which app is draining the most battery?")
        )
        analyticsTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "analytics_${idx + 1}",
                    name = pair.first,
                    category = "Analytics",
                    description = "Hardware telemetry and channel metrics explained in plain human language.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 10. Voice security (8 tools)
        val secTools = listOf(
            Pair("Voiceprint Enrollment", "Enroll my voiceprint sample."),
            Pair("Speaker Verification", "Verify who is currently speaking."),
            Pair("Guest Sandbox Mode", "Enable guest mode — block terminal and file deletion."),
            Pair("Intrusion Log Review", "Who spoke to you while I was away from desk?"),
            Pair("Anti-Spoofing Acoustic Filter", "Detect synthetic deepfake microphone input."),
            Pair("Security Arm / Disarm", "Arm voice guardian before I leave."),
            Pair("Emergency Lockout", "Emergency lockdown: kill live sessions and lock Windows."),
            Pair("Export Audit Trail", "Export timestamped voice audit log.")
        )
        secTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "sec_${idx + 1}",
                    name = pair.first,
                    category = "Voice security",
                    description = "Voiceprint recognition, anti-spoofing, and guest privilege gates.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 11. Music (8 tools)
        val musicTools = listOf(
            Pair("Play / Pause Any Media", "Pause the music."),
            Pair("Next Track", "Skip track."),
            Pair("Previous Track", "Go back to previous song."),
            Pair("Identify Playing Track", "What's this song? Add it to my favourites."),
            Pair("Taste Profile Rec", "Play something for focus."),
            Pair("Session History Queue", "What songs did I listen to this morning?"),
            Pair("Volume Boost By Voice", "Volume up 15%."),
            Pair("Audio Mixer Balancing", "Lower Discord volume, raise Spotify.")
        )
        musicTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "music_${idx + 1}",
                    name = pair.first,
                    category = "Music",
                    description = "Universal music management, taste learning, and mixer balancing.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 12. Study & whiteboard (6 tools)
        val studyTools = listOf(
            Pair("Open Interactive Whiteboard", "Explain how a transformer works. Draw it."),
            Pair("Equation Renderer", "Render the Fourier transform equation on screen."),
            Pair("Draw Flowchart", "Draw a flowchart of OAuth2 authorization code flow."),
            Pair("Export Whiteboard PNG", "Save the whiteboard as a PNG."),
            Pair("Flashcard Quiz Mode", "Quiz me on modern JavaScript array methods."),
            Pair("Concept Decomposition", "Break down quantum entanglement in 3 visual steps.")
        )
        studyTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "study_${idx + 1}",
                    name = pair.first,
                    category = "Study & whiteboard",
                    description = "Full-screen live whiteboard canvas that draws diagrams while Maya speaks.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 13. Email (4 tools)
        val emailTools = listOf(
            Pair("Summarize Unread Mail", "Any important email today?"),
            Pair("Dictate New Email", "Compose new email to Sarah with subject Project Update."),
            Pair("Voice Thread Reply", "Reply: I'll review it tonight."),
            Pair("Spam & Clutter Purge", "Clear out promotional newsletters from the last 7 days.")
        )
        emailTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "email_${idx + 1}",
                    name = pair.first,
                    category = "Email",
                    description = "Clean inbox management and voice dictation without opening a client.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 14. Camera & vision (4 tools)
        val camTools = listOf(
            Pair("Webcam Scene Description", "Look through webcam and describe what is on my desk."),
            Pair("Recognize People", "Who just walked behind me?"),
            Pair("Snapshot Webcam Photo", "Take a webcam picture and save to ~/Pictures."),
            Pair("Read Physical Document", "Read the printed letter held up to camera.")
        )
        camTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "cam_${idx + 1}",
                    name = pair.first,
                    category = "Camera & vision",
                    description = "Webcam vision, facial memory, and physical document reading.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 15. Screen recording (4 tools)
        val recTools = listOf(
            Pair("Start Recording", "Start screen recording."),
            Pair("Pause Recording", "Pause recording mid-take."),
            Pair("Resume Recording", "Resume recording."),
            Pair("Stop & Save Take", "Stop recording and export as 1080p MP4.")
        )
        recTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "rec_${idx + 1}",
                    name = pair.first,
                    category = "Screen recording",
                    description = "Voice-triggered screen capture without breaking content creator flow.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 16. Clipboard (3 tools)
        val clipTools = listOf(
            Pair("Read Clipboard History", "What did I copy three items ago?"),
            Pair("Clear Clipboard Buffer", "Clear sensitive passwords from clipboard."),
            Pair("Sync Phone Clipboard", "Send latest copied text to my phone.")
        )
        clipTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "clip_${idx + 1}",
                    name = pair.first,
                    category = "Clipboard",
                    description = "History tracking and cross-device clipboard synchronization.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 17. Coding agent (3 tools)
        val codeTools = listOf(
            Pair("Terminal Scaffolder", "Maya, build me a Flask API with JWT auth, SQLite, and a Dockerfile."),
            Pair("Error Watcher & Auto-Fix", "What did the build error say? Patch and re-run."),
            Pair("Engine Switcher", "Switch coding engine from Claude Code to HunterCode.")
        )
        codeTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "code_${idx + 1}",
                    name = pair.first,
                    category = "Coding agent",
                    description = "Autonomous terminal engineer operating live in VS Code.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 18. Finance (3 tools)
        val finTools = listOf(
            Pair("Live Stock Quotes", "What is NVDA trading at right now?"),
            Pair("Ticker Search & News", "Search recent earnings news for Apple."),
            Pair("Price History Readout", "Summarize Bitcoin price movements over the last week.")
        )
        finTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "fin_${idx + 1}",
                    name = pair.first,
                    category = "Finance",
                    description = "Real-time stock ticker, market summaries, and price action readout.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 19. Plugins (3 tools)
        val plugTools = listOf(
            Pair("Load Python Plugin", "Load plugin from ~/MayaPlugins/home_assistant.py."),
            Pair("Browse Plugin Directory", "Show popular community plugins."),
            Pair("Reload Hot Plugins", "Reload all plugins without restarting Maya.")
        )
        plugTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "plug_${idx + 1}",
                    name = pair.first,
                    category = "Plugins",
                    description = "Drop-in extension system turning custom Python functions into voice tools.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 20. Hermes agent (3 tools)
        val hermesTools = listOf(
            Pair("Launch Hermes Sandbox", "Hermes se bolo: ye dataset process karke report banaye."),
            Pair("Subscription Sign-In", "Connect Hermes using my Claude Pro subscription."),
            Pair("Self-Learning Skill Retainer", "Give Hermes the repo and let it add the feature.")
        )
        hermesTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "hermes_${idx + 1}",
                    name = pair.first,
                    category = "Hermes agent",
                    description = "Nous Research autonomous agent in sandboxed runtime with subscription sign-in.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 21. Expense tracker (2 tools)
        val expTools = listOf(
            Pair("Today's Spend Calculation", "How much did I spend today?"),
            Pair("Monthly Breakdown By Category", "What did last month go on?")
        )
        expTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "exp_${idx + 1}",
                    name = pair.first,
                    category = "Expense tracker",
                    description = "Inbox bank, UPI, and card receipts extractor with voice summary.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 22. Weather & smart home (2 tools)
        val weathTools = listOf(
            Pair("Current Hyper-Local Weather", "What's the weather and forecast for today?"),
            Pair("Smart Home Light Toggle", "Turn desk ambient lamp to soft orange.")
        )
        weathTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "weath_${idx + 1}",
                    name = pair.first,
                    category = "Weather & smart home",
                    description = "Hyperlocal forecast and local IoT device control.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 23. Live commentary (2 tools)
        val commTools = listOf(
            Pair("Start Commentary Mode", "Start commentary — roast my gameplay."),
            Pair("Stop Commentary Mode", "Stop commentary and summarize performance.")
        )
        commTools.forEachIndexed { idx, pair ->
            tools.add(
                EntityTool(
                    id = "comm_${idx + 1}",
                    name = pair.first,
                    category = "Live commentary",
                    description = "Real-time AI screen co-host reacting dynamically to gameplay and live coding.",
                    examplePrompt = pair.second,
                    isEnabled = true
                )
            )
        }

        // 24. Support (1 tool)
        tools.add(
            EntityTool(
                id = "support_1",
                name = "Diagnostics & One-Click Update",
                category = "Support",
                description = "Check for Maya 6.0.x patches, export logs, or run diagnostic self-test.",
                examplePrompt = "Check for updates and run diagnostic health check.",
                isEnabled = true
            )
        )

        return tools
    }

    val defaultTimeline: List<TimelineItem> = listOf(
        TimelineItem(
            time = "08:40",
            title = "Daily Briefing",
            userPrompt = "Morning. Daily briefing.",
            mayaResponse = "Good morning! 22°C and clear outside. You have 3 unread emails, YouTube gained +340 subscribers overnight, and the Q3 report draft is awaiting sign-off.",
            systemOutcome = "Retrieved weather, calendar, inbox summaries, and YouTube analytics in 1.4s.",
            category = "Core essentials",
            iconName = "wb_sunny"
        ),
        TimelineItem(
            time = "09:05",
            title = "Morning Setup Macro",
            userPrompt = "Run my morning setup macro.",
            mayaResponse = "Opening VS Code, launching Chrome tabs for GitHub & Figma, starting Spotify focus playlist, and cd-ing into ~/MayaProjects.",
            systemOutcome = "Macro 'morning setup' executed: 4 apps launched, windows snapped cleanly.",
            category = "Macros",
            iconName = "bolt"
        ),
        TimelineItem(
            time = "10:20",
            title = "Coding Agent Delegation",
            userPrompt = "Build the auth service. Watch it in the terminal.",
            mayaResponse = "Coding agent started in VS Code terminal. Scaffolding Flask API with JWT auth and SQLite. Running test suite now.",
            systemOutcome = "Claude Code completed 14 files in ~/MayaProjects/auth-svc. All unit tests pass.",
            category = "Coding agent",
            iconName = "terminal"
        ),
        TimelineItem(
            time = "12:00",
            title = "Screen Error Auto-Fix",
            userPrompt = "What did the build error say?",
            mayaResponse = "Missing jwt.exceptions import in auth.py. I've already patched the import and re-triggered pytest — all 8 tests passing now.",
            systemOutcome = "Terminal watcher caught traceback, invoked patch script, and verified exit code 0.",
            category = "PC control",
            iconName = "build"
        ),
        TimelineItem(
            time = "13:15",
            title = "WhatsApp Spec Dispatch",
            userPrompt = "Send Priya the spec, and attach the PDF.",
            mayaResponse = "WhatsApp opened, matched contact Priya Sharma, attached 'spec-v6.pdf' from Documents, and sent message.",
            systemOutcome = "Native WhatsApp API dispatched message and 4.2 MB attachment.",
            category = "WhatsApp",
            iconName = "chat"
        ),
        TimelineItem(
            time = "15:00",
            title = "3 Parallel Research Sub-Agents",
            userPrompt = "Research all three competitors. One report each.",
            mayaResponse = "Spawning three sub-agents in parallel. Agent A researching Competitor 1, Agent B on Competitor 2, Agent C on Competitor 3. I'll stay here if you need anything.",
            systemOutcome = "3 sub-agents ran concurrently; delivered 3 structured Word docs in 12 minutes.",
            category = "Hermes agent",
            iconName = "groups"
        ),
        TimelineItem(
            time = "16:30",
            title = "Live Stream Commentary",
            userPrompt = "Start recording. Start commentary.",
            mayaResponse = "OBS recording rolling. Commentary active: let's see how this boss fight goes — try not to dodge roll off the ledge this time!",
            systemOutcome = "Screen recorder engaged; live vision commentary pipeline analyzing frames at 10 fps.",
            category = "Live commentary",
            iconName = "videocam"
        ),
        TimelineItem(
            time = "18:00",
            title = "YouTube Publish & Tagging",
            userPrompt = "Stop. Upload it — title it Episode 12.",
            mayaResponse = "Recording stopped and compressed. Generated tags and SEO description. Uploading 'Episode 12: Speedrun Attempts' to YouTube Studio now.",
            systemOutcome = "Video uploaded to YouTube Studio in draft mode with generated thumbnail and metadata.",
            category = "YouTube",
            iconName = "smart_display"
        ),
        TimelineItem(
            time = "20:45",
            title = "Phone Link Delivery Check",
            userPrompt = "Ask my phone if the delivery arrived.",
            mayaResponse = "Checking your paired Android... Found delivery notification from Amazon 12 minutes ago: 'Package left at front door'.",
            systemOutcome = "Phone Link query bridged over encrypted local session; battery & notification verified.",
            category = "Accessibility",
            iconName = "smartphone"
        ),
        TimelineItem(
            time = "23:10",
            title = "Invoice & Nightly Sleep",
            userPrompt = "Remind me Monday at nine to invoice. Then sleep the PC.",
            mayaResponse = "Scheduled recurring invoice reminder for Monday 9:00 AM. Goodnight! Putting the computer to sleep now.",
            systemOutcome = "Calendar entry booked; Windows entered ACPI S3 sleep state.",
            category = "Core essentials",
            iconName = "bedtime"
        )
    )
}
