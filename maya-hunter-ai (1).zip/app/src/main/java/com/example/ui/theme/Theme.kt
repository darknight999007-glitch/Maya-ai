package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val MayaDarkColorScheme = darkColorScheme(
    primary = MayaCrimson,
    onPrimary = TextPrimary,
    primaryContainer = MayaCrimsonDark,
    onPrimaryContainer = TextPrimary,
    secondary = MayaCyan,
    onSecondary = MayaDarkBg,
    secondaryContainer = MayaSurfaceVariant,
    onSecondaryContainer = MayaCyan,
    tertiary = MayaAmber,
    background = MayaDarkBg,
    onBackground = TextPrimary,
    surface = MayaSurface,
    onSurface = TextPrimary,
    surfaceVariant = MayaSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = MayaBorder
)

private val MayaLightColorScheme = lightColorScheme(
    primary = MayaCrimson,
    onPrimary = TextPrimary,
    primaryContainer = MayaCrimsonLight,
    onPrimaryContainer = MayaDarkBg,
    secondary = MayaCyan,
    background = MayaDarkBg,
    surface = MayaSurface
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force futuristic Maya dark aesthetic by default
    content: @Composable () -> Unit
) {
    val colorScheme = MayaDarkColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = MayaDarkBg.toArgb()
                window.navigationBarColor = MayaDarkBg.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
