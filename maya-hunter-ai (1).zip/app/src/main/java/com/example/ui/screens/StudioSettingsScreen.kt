package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MayaViewModel
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaEmerald
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.MayaSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun StudioSettingsScreen(
    viewModel: MayaViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val memories by viewModel.allMemories.collectAsStateWithLifecycle()
    val macros by viewModel.allMacros.collectAsStateWithLifecycle()

    var isAddMemoryOpen by remember { mutableStateOf(false) }
    var memoryKeyInput by remember { mutableStateOf("") }
    var memoryContentInput by remember { mutableStateOf("") }

    var macroTitleInput by remember { mutableStateOf("") }
    var macroTriggerInput by remember { mutableStateOf("") }
    var macroStepsInput by remember { mutableStateOf("") }

    var isGuestModeArmed by remember { mutableStateOf(false) }

    val codingEngines = listOf("Claude Code", "HunterCode")
    val codingModes = listOf("Visible Mode", "Quiet Mode")
    val modelProviders = listOf(
        "Google Gemini Live API",
        "OpenAI",
        "OpenRouter",
        "Groq",
        "DeepSeek",
        "Ollama (Local Offline)",
        "LM Studio"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MayaDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        item {
            Column {
                Text(
                    text = "SPECIFICATIONS & ENGINE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = MayaCrimson
                )
                Text(
                    text = "Coding Engine & Universal BYOM",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Runs on the PC you already own. One installer, one API key, zero subscriptions to a middleman.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
            }
        }

        // Coding Engine Selector (Brochure Page 8)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MayaSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CODING ENGINE SELECTION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MayaCyan,
                            letterSpacing = 1.sp
                        )
                        Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = MayaCyan, modifier = Modifier.size(18.dp))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Projects live in ~/MayaProjects. Maya creates the project, picks the stack, runs tests, and fixes build errors in the terminal.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        codingEngines.forEach { engine ->
                            val isSelected = uiState.activeCodingEngine == engine
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) MayaCrimson else MayaSurfaceVariant)
                                    .clickable { viewModel.setCodingEngine(engine) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = engine,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) TextPrimary else TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "TERMINAL EXECUTION MODE", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        codingModes.forEach { mode ->
                            val isSelected = uiState.codingMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) MayaSurfaceVariant else MayaDarkBg)
                                    .border(1.dp, if (isSelected) MayaCyan else MayaBorder, RoundedCornerShape(10.dp))
                                    .clickable { viewModel.setCodingMode(mode) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = mode,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) MayaCyan else TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Universal BYOM (Bring Your Own Model) Endpoint (Brochure Page 8)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MayaSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "BRING YOUR OWN MODEL · UNIVERSAL API",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MayaCrimson,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Maya is not locked to one AI vendor. Point text, coding, and document reasoning at any OpenAI-compatible or Gemini endpoint.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    modelProviders.forEach { provider ->
                        val isSelected = uiState.selectedModelEndpoint == provider
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) MayaSurfaceVariant else MayaDarkBg)
                                .border(1.dp, if (isSelected) MayaCrimson else MayaBorder, RoundedCornerShape(8.dp))
                                .clickable { viewModel.setModelEndpoint(provider) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = provider,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) TextPrimary else TextSecondary
                            )
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(MayaEmerald)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Voice Guardian Security Gate (Brochure Page 11)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MayaSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MayaEmerald, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "VOICE GUARDIAN (8 TOOLS)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MayaEmerald,
                                letterSpacing = 1.sp
                            )
                        }

                        Text(
                            text = "Enrolled",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MayaEmerald
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Maya learns your voiceprint. Guests get a restricted toolset — no file deletion, no terminal, no personal memory. Arm her and she'll tell you who spoke while away.",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Guest Sandbox Restriction", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Lock system tools for unfamiliar voices", fontSize = 11.sp, color = TextSecondary)
                        }
                        Switch(
                            checked = isGuestModeArmed,
                            onCheckedChange = { isGuestModeArmed = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = TextPrimary,
                                checkedTrackColor = MayaEmerald
                            ),
                            modifier = Modifier.testTag("guest_mode_switch")
                        )
                    }
                }
            }
        }

        // Persistent Local Memory Inspector (Brochure Page 11)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MayaSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Memory, contentDescription = null, tint = MayaCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "LOCAL PLAIN-FILE MEMORY",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MayaCyan,
                                letterSpacing = 1.sp
                            )
                        }

                        IconButton(
                            onClick = { isAddMemoryOpen = true },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Memory", tint = MayaCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Sentence-level facts about your life, projects, and routines stored locally in plain files. She recalls them unprompted, and forgets on command.",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    memories.forEach { mem ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MayaSurfaceVariant)
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = mem.key, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MayaCyan)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(text = mem.content, fontSize = 11.sp, color = TextPrimary)
                                }
                                IconButton(
                                    onClick = { viewModel.deleteMemory(mem.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Custom Macros List
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MayaSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TEACH BY DOING (13 MACROS)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MayaCrimson,
                            letterSpacing = 1.sp
                        )
                        IconButton(
                            onClick = { viewModel.showAddMacro(true) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Macro", tint = MayaCrimson)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    macros.forEach { macro ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MayaSurfaceVariant)
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = macro.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(text = "Trigger: \"${macro.triggerPhrase}\"", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MayaCyan)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = macro.stepsDescription, fontSize = 10.sp, color = TextSecondary, lineHeight = 14.sp)
                                }
                                IconButton(
                                    onClick = { viewModel.deleteMacro(macro.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Memory Dialog
    if (isAddMemoryOpen) {
        AlertDialog(
            onDismissRequest = { isAddMemoryOpen = false },
            containerColor = MayaSurface,
            shape = RoundedCornerShape(16.dp),
            title = { Text("Add Plain-File Memory", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = memoryKeyInput,
                        onValueChange = { memoryKeyInput = it },
                        label = { Text("Topic / Key", color = TextSecondary) },
                        placeholder = { Text("e.g. Favorite Editor", color = TextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MayaCrimson,
                            unfocusedBorderColor = MayaBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = memoryContentInput,
                        onValueChange = { memoryContentInput = it },
                        label = { Text("Fact Content", color = TextSecondary) },
                        placeholder = { Text("e.g. Likes light themes when outdoors", color = TextMuted) },
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MayaCrimson,
                            unfocusedBorderColor = MayaBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (memoryKeyInput.isNotBlank() && memoryContentInput.isNotBlank()) {
                            viewModel.addMemory(memoryKeyInput.trim(), memoryContentInput.trim(), "Custom")
                            memoryKeyInput = ""
                            memoryContentInput = ""
                            isAddMemoryOpen = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MayaCrimson)
                ) {
                    Text("Save Fact")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { isAddMemoryOpen = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Add Macro Dialog
    if (uiState.isAddMacroVisible) {
        AlertDialog(
            onDismissRequest = { viewModel.showAddMacro(false) },
            containerColor = MayaSurface,
            shape = RoundedCornerShape(16.dp),
            title = { Text("Create New Voice Macro", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = macroTitleInput,
                        onValueChange = { macroTitleInput = it },
                        label = { Text("Macro Title", color = TextSecondary) },
                        placeholder = { Text("e.g. Deep Work Setup", color = TextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MayaCrimson,
                            unfocusedBorderColor = MayaBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = macroTriggerInput,
                        onValueChange = { macroTriggerInput = it },
                        label = { Text("Voice Trigger", color = TextSecondary) },
                        placeholder = { Text("e.g. Start my deep work session", color = TextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MayaCrimson,
                            unfocusedBorderColor = MayaBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = macroStepsInput,
                        onValueChange = { macroStepsInput = it },
                        label = { Text("Steps to Replay", color = TextSecondary) },
                        placeholder = { Text("1. Close Discord\\n2. Launch Obsidian\\n3. Set do not disturb", color = TextMuted) },
                        minLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MayaCrimson,
                            unfocusedBorderColor = MayaBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (macroTitleInput.isNotBlank() && macroTriggerInput.isNotBlank()) {
                            viewModel.saveMacro(macroTitleInput.trim(), macroTriggerInput.trim(), macroStepsInput.trim())
                            macroTitleInput = ""
                            macroTriggerInput = ""
                            macroStepsInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MayaCrimson)
                ) {
                    Text("Save Macro")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { viewModel.showAddMacro(false) }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
