package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MainTab
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.MayaSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MayaNavDrawerContent(
    currentTab: MainTab,
    onNavigateTab: (MainTab) -> Unit,
    onOpenSettings: () -> Unit,
    onCloseDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(300.dp)
            .background(MayaDarkBg)
            .padding(vertical = 18.dp, horizontal = 16.dp)
    ) {
        // Drawer Header matching Screenshot 2 & 3
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.maya_avatar),
                    contentDescription = "Maya Avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MayaSurfaceVariant)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Maya",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "by The Hunter AI",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }

            IconButton(
                onClick = onCloseDrawer,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifications",
                    tint = TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        HorizontalDivider(color = MayaBorder, thickness = 1.dp)
        Spacer(modifier = Modifier.height(12.dp))

        // Navigation Menu Items
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Group: HOME
            item {
                DrawerSectionHeader(title = "HOME")
            }
            item {
                DrawerItem(
                    title = "Home",
                    icon = Icons.Default.Home,
                    isSelected = currentTab == MainTab.HUD,
                    onClick = {
                        onNavigateTab(MainTab.HUD)
                        onCloseDrawer()
                    }
                )
            }
            item {
                DrawerItem(
                    title = "Memories",
                    icon = Icons.Default.Lightbulb,
                    isSelected = false,
                    onClick = {
                        onNavigateTab(MainTab.STUDIO)
                        onCloseDrawer()
                    }
                )
            }
            item {
                DrawerItem(
                    title = "Chat",
                    icon = Icons.Default.Chat,
                    isSelected = false,
                    onClick = {
                        onNavigateTab(MainTab.HUD)
                        onCloseDrawer()
                    }
                )
            }

            // Group: PRODUCTIVITY
            item {
                DrawerSectionHeader(title = "PRODUCTIVITY")
            }
            item {
                DrawerItem(
                    title = "Markets & Finance",
                    icon = Icons.Default.TrendingUp,
                    isSelected = false,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }
            item {
                DrawerItem(
                    title = "Marketing & YouTube",
                    icon = Icons.Default.Storefront,
                    isSelected = false,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }
            item {
                DrawerItem(
                    title = "Documents",
                    icon = Icons.Default.Description,
                    isSelected = false,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }
            item {
                DrawerItem(
                    title = "Website / Coding",
                    icon = Icons.Default.Code,
                    isSelected = false,
                    onClick = {
                        onNavigateTab(MainTab.FLEET)
                        onCloseDrawer()
                    }
                )
            }
            item {
                DrawerItem(
                    title = "Study / Whiteboard",
                    icon = Icons.Default.Edit,
                    isSelected = false,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }

            // Group: SYSTEM
            item {
                DrawerSectionHeader(title = "SYSTEM")
            }
            item {
                DrawerItem(
                    title = "Settings",
                    icon = Icons.Default.Settings,
                    isSelected = currentTab == MainTab.STUDIO,
                    onClick = {
                        onOpenSettings()
                        onCloseDrawer()
                    }
                )
            }
            item {
                DrawerItem(
                    title = "Maya Rules & Tools (234)",
                    icon = Icons.Default.Apps,
                    isSelected = currentTab == MainTab.TOOLS,
                    onClick = {
                        onNavigateTab(MainTab.TOOLS)
                        onCloseDrawer()
                    }
                )
            }
            item {
                DrawerItem(
                    title = "PC ⇄ Phone Link",
                    icon = Icons.Default.SwapHoriz,
                    isSelected = currentTab == MainTab.PHONE_LINK,
                    onClick = {
                        onNavigateTab(MainTab.PHONE_LINK)
                        onCloseDrawer()
                    }
                )
            }

            // Group: OTHER
            item {
                DrawerSectionHeader(title = "OTHER")
            }
            item {
                DrawerItem(
                    title = "Privacy Policy",
                    icon = Icons.Default.Lock,
                    isSelected = false,
                    onClick = onCloseDrawer
                )
            }
            item {
                DrawerItem(
                    title = "About",
                    icon = Icons.Default.Info,
                    isSelected = false,
                    onClick = onCloseDrawer
                )
            }
            item {
                DrawerItem(
                    title = "Upgrade License",
                    icon = Icons.Default.Star,
                    isSelected = false,
                    onClick = onCloseDrawer
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "v6.0.8 · The Hunter AI",
            fontSize = 11.sp,
            color = TextMuted,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
private fun DrawerSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = TextMuted,
        modifier = Modifier.padding(start = 12.dp, top = 14.dp, bottom = 4.dp)
    )
}

@Composable
private fun DrawerItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) MayaSurfaceVariant else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 11.dp)
            .testTag("drawer_item_${title.take(6).lowercase()}")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) MayaCrimson else TextSecondary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) TextPrimary else TextSecondary
            )
        }
    }
}
