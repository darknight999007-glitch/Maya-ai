package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AgentFleetMember
import com.example.ui.MayaViewModel
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaEmerald
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.MayaSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentFleetScreen(
    viewModel: MayaViewModel,
    modifier: Modifier = Modifier
) {
    val agentFleet by viewModel.agentFleet.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    var newAgentName by remember { mutableStateOf("") }
    var newAgentMission by remember { mutableStateOf("") }
    var newAgentType by remember { mutableStateOf("Sub-agent") }
    var isTypeMenuExpanded by remember { mutableStateOf(false) }

    val agentTypes = listOf(
        "Sub-agent",
        "Hermes agent",
        "Coding agent",
        "Browser agent",
        "Desktop agent",
        "Research agent",
        "Document agent",
        "Skill author"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MayaDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DELEGATION · NEW IN 6.0",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MayaCrimson
                    )
                    Text(
                        text = "Autonomous Agent Fleet",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Button(
                    onClick = { viewModel.showDelegateModal(true) },
                    colors = ButtonDefaults.buttonColors(containerColor = MayaCrimson),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("delegate_mission_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delegate", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "She doesn't do the big jobs herself. She sends someone. Ask for five things at once and she runs five agents in parallel without blocking the conversation.",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )
        }

        items(
            items = agentFleet,
            key = { it.id }
        ) { agent ->
            AgentCard(
                agent = agent,
                onAdvanceStep = { viewModel.advanceAgentProgress(agent.id) }
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MayaSurface),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "NO CONVERSATION BLOCKING",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MayaCyan
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Every agent runs headless or inside an isolated Windows terminal. Maya never goes silent waiting on one — she cuts back in the moment a job finishes, fails, or needs a decision from you.",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }

    // Delegate New Mission Dialog
    if (uiState.isDelegateModalVisible) {
        AlertDialog(
            onDismissRequest = { viewModel.showDelegateModal(false) },
            containerColor = MayaSurface,
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(
                    text = "Delegate Autonomous Mission",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Maya will spawn a background worker with its own toolset and runtime.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = newAgentName,
                        onValueChange = { newAgentName = it },
                        label = { Text("Agent Label", color = TextSecondary) },
                        placeholder = { Text("e.g. ScrapeCompetitorDocs", color = TextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MayaCrimson,
                            unfocusedBorderColor = MayaBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Agent Type Dropdown
                    ExposedDropdownMenuBox(
                        expanded = isTypeMenuExpanded,
                        onExpandedChange = { isTypeMenuExpanded = !isTypeMenuExpanded }
                    ) {
                        OutlinedTextField(
                            value = newAgentType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Specialized Agent Type", color = TextSecondary) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTypeMenuExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MayaCrimson,
                                unfocusedBorderColor = MayaBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )

                        ExposedDropdownMenu(
                            expanded = isTypeMenuExpanded,
                            onDismissRequest = { isTypeMenuExpanded = false },
                            modifier = Modifier.background(MayaSurfaceVariant)
                        ) {
                            agentTypes.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type, color = TextPrimary) },
                                    onClick = {
                                        newAgentType = type
                                        isTypeMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newAgentMission,
                        onValueChange = { newAgentMission = it },
                        label = { Text("Mission Objective", color = TextSecondary) },
                        placeholder = { Text("Describe the task, files, or research...", color = TextMuted) },
                        minLines = 3,
                        maxLines = 5,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MayaCrimson,
                            unfocusedBorderColor = MayaBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = if (newAgentName.isNotBlank()) newAgentName.trim() else "Agent-${(100..999).random()}"
                        val mission = if (newAgentMission.isNotBlank()) newAgentMission.trim() else "Open-ended execution task"
                        viewModel.spawnAgent(name, mission, newAgentType)
                        newAgentName = ""
                        newAgentMission = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MayaCrimson),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Spawn Agent")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.showDelegateModal(false) },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun AgentCard(
    agent: AgentFleetMember,
    onAdvanceStep: () -> Unit
) {
    var isLogsExpanded by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MayaSurface),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (agent.status == "RUNNING") MayaBorder else MayaBorder.copy(alpha = 0.5f)
            )
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("agent_card_${agent.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = agent.type.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MayaCyan
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = agent.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (agent.status == "COMPLETED") MayaEmerald.copy(alpha = 0.15f) else MayaCrimson.copy(alpha = 0.15f))
                        .border(
                            1.dp,
                            if (agent.status == "COMPLETED") MayaEmerald else MayaCrimson,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = agent.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (agent.status == "COMPLETED") MayaEmerald else MayaCrimson
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = agent.currentMission,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Progress Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Engine: ${agent.engine}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
                Text(
                    text = "${(agent.progress * 100).toInt()}%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (agent.status == "COMPLETED") MayaEmerald else MayaCrimson
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { agent.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (agent.status == "COMPLETED") MayaEmerald else MayaCrimson,
                trackColor = MayaSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Logs Toggle & Advance Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { isLogsExpanded = !isLogsExpanded }
                        .padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = MayaCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isLogsExpanded) "Hide Terminal" else "View Terminal Logs (${agent.logs.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MayaCyan
                    )
                    Icon(
                        imageVector = if (isLogsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = MayaCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }

                if (agent.status == "RUNNING") {
                    Button(
                        onClick = onAdvanceStep,
                        colors = ButtonDefaults.buttonColors(containerColor = MayaSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier
                            .border(1.dp, MayaBorder, RoundedCornerShape(8.dp))
                            .testTag("advance_agent_${agent.id}")
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = MayaCyan, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Advance Step", fontSize = 10.sp, color = TextPrimary)
                    }
                }
            }

            // Expanded Terminal Logs Box
            AnimatedVisibility(visible = isLogsExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MayaDarkBg)
                        .border(1.dp, MayaBorder, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    agent.logs.forEach { logLine ->
                        Text(
                            text = "> $logLine",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}
