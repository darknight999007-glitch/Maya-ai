package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MayaDarkBg = Color(0xFF090A0F)
val MayaSurface = Color(0xFF121622)
val MayaSurfaceVariant = Color(0xFF1B2232)
val MayaBorder = Color(0xFF283347)

val MayaCrimson = Color(0xFFFF2A4D)
val MayaCrimsonDark = Color(0xFFC71030)
val MayaCrimsonLight = Color(0xFFFF6B84)

val MayaCyan = Color(0xFF00E5FF)
val MayaEmerald = Color(0xFF00E676)
val MayaAmber = Color(0xFFFFB300)
val MayaPurple = Color(0xFFB388FF)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val PersonaMayaColor = Color(0xFFFF2A4D)
val PersonaFridayColor = Color(0xFF00E5FF)
val PersonaVenomColor = Color(0xFF9C27B0)
