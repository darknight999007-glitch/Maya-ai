package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender
import com.example.ui.MayaViewModel
import com.example.ui.components.InteractiveCharacterView
import com.example.ui.components.MayaWaveformOrb
import com.example.ui.components.PersonaSelector
import com.example.ui.theme.MayaBorder
import com.example.ui.theme.MayaCrimson
import com.example.ui.theme.MayaCyan
import com.example.ui.theme.MayaDarkBg
import com.example.ui.theme.MayaEmerald
import com.example.ui.theme.MayaSurface
import com.example.ui.theme.MayaSurfaceVariant
import com.example.ui.theme.PersonaFridayColor
import com.example.ui.theme.PersonaMayaColor
import com.example.ui.theme.PersonaVenomColor
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LiveHudScreen(
    viewModel: MayaViewModel,
    onOpenDrawer: () -> Unit,
    onOpenSetupModal: () -> Unit,
    modifier: Modifier = Modifier
) {
    val persona by viewModel.currentPersona.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceEngine.isSpeaking.collectAsStateWithLifecycle()
    val isListening by viewModel.voiceEngine.isListening.collectAsStateWithLifecycle()
    val waveformLevel by viewModel.voiceEngine.audioWaveformLevel.collectAsStateWithLifecycle()
    val conversation by viewModel.conversation.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()

    var showCharacterView by remember { mutableStateOf(true) }
    var isContinuousListeningEnabled by remember { mutableStateOf(false) }
    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    val currentDateStr = remember {
        SimpleDateFormat("d\nEEE, MMM", Locale.ENGLISH).format(Date())
    }

    val quickActionPills = listOf(
        Pair("Music", Icons.Default.MusicNote),
        Pair("Study", Icons.Default.School),
        Pair("Vent", Icons.Default.Chat),
        Pair("Photo", Icons.Default.CameraAlt),
        Pair("Journal", Icons.Default.Edit)
    )

    // Auto-scroll to the newest message whenever message count changes
    LaunchedEffect(conversation.size, isThinking) {
        if (conversation.isNotEmpty()) {
            listState.animateScrollToItem(conversation.size + 8)
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxSize()
            .background(MayaDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp)
    ) {
        // TOP APP BAR (Matching Screenshot 1 & 3)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Menu Hamburger Icon (Opens Left Drawer)
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MayaSurfaceVariant)
                        .testTag("open_drawer_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Open Menu Drawer",
                        tint = TextPrimary
                    )
                }

                // Center Title
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "M A Y A",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 3.sp,
                        color = MayaCyan
                    )
                    Text(
                        text = "PERSONAL AI · v6.0.8",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = TextMuted
                    )
                }

                // Energy / Streak Badges (Matching Screenshot 1 & 3)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MayaSurfaceVariant)
                            .border(1.dp, MayaBorder, RoundedCornerShape(12.dp))
                            .clickable { onOpenSetupModal() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = null,
                                tint = MayaCrimson,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "6",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onOpenSetupModal,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Setup Notification",
                            tint = MayaCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // LICENSE / FREE MODE BANNER (From Screenshot 3)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFF16213E),
                                Color(0xFF0F1B2B)
                            )
                        )
                    )
                    .border(1.dp, MayaBorder, RoundedCornerShape(14.dp))
                    .clickable { onOpenSetupModal() }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(MayaCyan)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Free mode • Unlimited talk active",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Connected with Windows Desktop & Phone Link",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MayaCyan)
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "Config",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MayaDarkBg
                        )
                    }
                }
            }
        }

        // GREETING HEADER (Large & Attractive Typography as requested)
        item {
            Column(modifier = Modifier.padding(top = 4.dp)) {
                Text(
                    text = "Good evening, Jaanu 😍✨",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isSpeaking) MayaEmerald else if (isListening) MayaCyan else MayaCrimson)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isSpeaking) "Maya is speaking now..." else "Ready when you are — say \"Hey Maya\"",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondary
                    )
                }
            }
        }

        // VIEW MODE TOGGLE (3D Animated Character vs Cyber Radar)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(MayaSurfaceVariant)
                        .border(1.dp, MayaBorder, RoundedCornerShape(20.dp))
                        .padding(4.dp)
                ) {
                    Row {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (showCharacterView) MayaCrimson else Color.Transparent)
                                .clickable { showCharacterView = true }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "✨ 3D Live Character",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (showCharacterView) TextPrimary else TextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (!showCharacterView) MayaCyan else Color.Transparent)
                                .clickable { showCharacterView = false }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "🎯 Cyber HUD Radar",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (!showCharacterView) MayaDarkBg else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // MAIN HERO DISPLAY: EITHER 3D CHARACTER OR RADAR ORB
        item {
            if (showCharacterView) {
                // Interactive Moving Character (Moving body, neck, hands, mouth lip-sync!)
                InteractiveCharacterView(
                    isSpeaking = isSpeaking,
                    isListening = isListening,
                    waveformLevel = waveformLevel,
                    persona = persona,
                    onCharacterClick = {
                        if (isSpeaking) viewModel.interruptSpeaking()
                        else viewModel.voiceEngine.startListening()
                    }
                )
            } else {
                // Cyber Waveform Orb
                MayaWaveformOrb(
                    isSpeaking = isSpeaking,
                    isListening = isListening,
                    waveformLevel = waveformLevel,
                    persona = persona,
                    onOrbClick = {
                        if (isSpeaking) viewModel.interruptSpeaking()
                        else viewModel.voiceEngine.startListening()
                    },
                    onInterruptClick = { viewModel.interruptSpeaking() }
                )
            }
        }

        // QUICK ACTION PILLS (Matching Screenshot 1 & 3: Music, Study, Vent, Photo, Journal)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                quickActionPills.forEach { pill ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 2.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MayaSurfaceVariant)
                            .border(1.dp, MayaBorder, RoundedCornerShape(14.dp))
                            .clickable {
                                when (pill.first) {
                                    "Music" -> viewModel.processVoiceCommand("Play Lo-Fi chill focus music on YouTube")
                                    "Study" -> viewModel.processVoiceCommand("Open Study Whiteboard and explain transformer architecture")
                                    "Vent" -> viewModel.processVoiceCommand("আজকে মনটা একটু খারাপ, তোমার সাথে কথা বলতে চাই")
                                    "Photo" -> viewModel.processVoiceCommand("Look through webcam and capture photo")
                                    "Journal" -> viewModel.processVoiceCommand("Add memory: completed Maya companion setup today")
                                }
                            }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = pill.second,
                                contentDescription = pill.first,
                                tint = MayaCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = pill.first,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }

        // THREE STATUS WIDGET CARDS (Weather, Today, Mood - from Screenshot 1 & 3)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Weather Widget
                WidgetCard(
                    title = "WEATHER",
                    primaryText = "28°C",
                    subText = "Clear & Sunny",
                    icon = Icons.Default.WbSunny,
                    accentColor = Color(0xFFFFB300),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.processVoiceCommand("আজকের আবহাওয়া কেমন?") }
                )

                // Today Widget
                WidgetCard(
                    title = "TODAY",
                    primaryText = "30",
                    subText = "Wed, Sep",
                    icon = Icons.Default.Bolt,
                    accentColor = MayaCyan,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.processVoiceCommand("Morning daily briefing") }
                )

                // Mood Widget
                WidgetCard(
                    title = "MOOD",
                    primaryText = "Warm",
                    subText = "All good ❤️",
                    icon = Icons.Default.CheckCircle,
                    accentColor = MayaCrimson,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.processVoiceCommand("কেমন আছো মায়া?") }
                )
            }
        }

        // ALWAYS-ON VOICE LISTENING BAR
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MayaSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(
                        if (isContinuousListeningEnabled) MayaCyan else MayaBorder
                    )
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(if (isContinuousListeningEnabled) MayaCyan else MayaSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isContinuousListeningEnabled) Icons.Default.Mic else Icons.Default.MicOff,
                                contentDescription = null,
                                tint = if (isContinuousListeningEnabled) MayaDarkBg else TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "অলটাইম ভয়েস লিসেনিং (Always Listen)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = if (isContinuousListeningEnabled) "সক্রিয় — আপনি কথা বললেই মায়া শুনবে" else "সুইচ অন করলে সব সময় শুনবে",
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Switch(
                        checked = isContinuousListeningEnabled,
                        onCheckedChange = {
                            isContinuousListeningEnabled = it
                            if (it) {
                                viewModel.voiceEngine.startListening()
                            } else {
                                viewModel.voiceEngine.stopListening()
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TextPrimary,
                            checkedTrackColor = MayaCyan
                        ),
                        modifier = Modifier.testTag("always_listen_switch")
                    )
                }
            }
        }

        // PERSONA SELECTOR (Maya, Friday, Venom)
        item {
            PersonaSelector(
                selectedPersona = persona,
                onSelectPersona = { viewModel.setPersona(it) }
            )
        }

        // CHAT / VOICE INPUT BAR (Matching Screenshot 1 & 3: "Ask Maya anything..." with clip & send)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MayaSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.processVoiceCommand("Send Mom yesterday's photos and attach documents") },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = "Attach",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("Ask Maya anything...", fontSize = 13.sp, color = TextMuted) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (textInput.isNotBlank()) {
                                    viewModel.processVoiceCommand(textInput.trim())
                                    textInput = ""
                                }
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = MayaCrimson
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field")
                    )

                    // Big glowing Mic Button or Send Button
                    if (textInput.isBlank()) {
                        IconButton(
                            onClick = {
                                if (isListening) viewModel.voiceEngine.stopListening()
                                else viewModel.voiceEngine.startListening()
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (isListening) MayaCrimson else MayaCyan)
                                .testTag("mic_circle_button")
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Mic",
                                tint = if (isListening) TextPrimary else MayaDarkBg,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    } else {
                        IconButton(
                            onClick = {
                                if (textInput.isNotBlank()) {
                                    viewModel.processVoiceCommand(textInput.trim())
                                    textInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MayaCrimson)
                                .testTag("send_msg_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = TextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // PROMINENT SECTION: LIVE SPEECH & WRITTEN DIALOGUE (কথা বলবে ও লিখে দিবে)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = MayaCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIVE SPEECH & WRITTEN DIALOGUE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp,
                        color = TextPrimary
                    )
                }
                Text(
                    text = "কথা বলবে ও লিখে দিবে",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MayaEmerald
                )
            }
        }

        // All Conversation Messages
        items(
            items = conversation,
            key = { it.id }
        ) { message ->
            LiveMessageBubble(
                message = message,
                onReplayAudio = { viewModel.replayMessage(message) },
                onCopy = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Maya Message", message.text))
                }
            )
        }

        // Thinking Indicator
        if (isThinking) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MayaSurfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = MayaCrimson,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "মায়া চিন্তা করছে এবং ভয়েস রেডি করছে...",
                            fontSize = 13.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun WidgetCard(
    title: String,
    primaryText: String,
    subText: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MayaSurface),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MayaBorder)),
        modifier = modifier
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = TextMuted
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(14.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = primaryText,
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subText,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun LiveMessageBubble(
    message: ChatMessage,
    onReplayAudio: () -> Unit,
    onCopy: () -> Unit
) {
    val isUser = message.sender == MessageSender.USER
    val personaAccent = when (message.persona) {
        com.example.data.model.MayaPersona.MAYA -> PersonaMayaColor
        com.example.data.model.MayaPersona.FRIDAY -> PersonaFridayColor
        com.example.data.model.MayaPersona.VENOM -> PersonaVenomColor
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isUser) MayaSurfaceVariant else MayaSurface
        ),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (isUser) MayaCyan.copy(alpha = 0.5f) else personaAccent.copy(alpha = 0.6f)
            )
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bubble_${message.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(if (isUser) MayaCyan else personaAccent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isUser) Icons.Default.Person else Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = MayaDarkBg,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUser) "You (আপনি)" else "${message.persona.title} · Voice AI",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isUser) MayaCyan else TextPrimary
                    )
                }

                if (!isUser && message.executedAction != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MayaSurfaceVariant)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = message.executedAction,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MayaEmerald
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Written Response Text (লিখে দিবে)
            Text(
                text = message.text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 22.sp,
                color = TextPrimary
            )

            // Audio Replay button & Copy button
            if (!isUser) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onReplayAudio,
                        colors = ButtonDefaults.buttonColors(containerColor = MayaSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .border(1.dp, personaAccent, RoundedCornerShape(8.dp))
                            .testTag("listen_voice_${message.id}")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Listen",
                            tint = personaAccent,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ভয়েস শুনুন (Listen)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    IconButton(
                        onClick = onCopy,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy text",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
