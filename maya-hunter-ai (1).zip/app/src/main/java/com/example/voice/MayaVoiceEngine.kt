package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.MayaPersona
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class MayaVoiceEngine(private val context: Context) : TextToSpeech.OnInitListener {

    private val TAG = "MayaVoiceEngine"
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isTtsReady = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var autoDoneRunnable: Runnable? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _audioWaveformLevel = MutableStateFlow(0.1f)
    val audioWaveformLevel: StateFlow<Float> = _audioWaveformLevel.asStateFlow()

    var onSpeechRecognized: ((String) -> Unit)? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing TextToSpeech", e)
        }
        setupSpeechRecognizer()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            try {
                tts?.setLanguage(Locale.US)
            } catch (e: Exception) {
                Log.w(TAG, "Locale setup error: ${e.message}")
            }

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    mainHandler.post {
                        _isSpeaking.value = true
                        _audioWaveformLevel.value = 0.85f
                    }
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post {
                        _isSpeaking.value = false
                        _audioWaveformLevel.value = 0.1f
                    }
                }

                override fun onError(utteranceId: String?) {
                    mainHandler.post {
                        _isSpeaking.value = false
                        _audioWaveformLevel.value = 0.1f
                    }
                }
            })
        }
    }

    private fun setupSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            try {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _isListening.value = true
                        }

                        override fun onBeginningOfSpeech() {
                            _audioWaveformLevel.value = 0.9f
                        }

                        override fun onRmsChanged(rmsdB: Float) {
                            _audioWaveformLevel.value = ((rmsdB + 2f) / 12f).coerceIn(0.1f, 1.0f)
                        }

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            _isListening.value = false
                            _audioWaveformLevel.value = 0.2f
                        }

                        override fun onError(error: Int) {
                            _isListening.value = false
                            _audioWaveformLevel.value = 0.1f
                            Log.d(TAG, "Speech recognizer error code: $error")
                        }

                        override fun onResults(results: Bundle?) {
                            _isListening.value = false
                            _audioWaveformLevel.value = 0.1f
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            if (!matches.isNullOrEmpty()) {
                                onSpeechRecognized?.invoke(matches[0])
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error creating speech recognizer", e)
            }
        }
    }

    fun speak(text: String, persona: MayaPersona) {
        if (text.isBlank()) return

        // Always register the spoken text immediately
        _lastSpokenText.value = text
        _isSpeaking.value = true
        _audioWaveformLevel.value = 0.85f

        // Cancel previous auto-done timer
        autoDoneRunnable?.let { mainHandler.removeCallbacks(it) }

        // Multi-tier TTS handling
        val isBengali = text.any { it in '\u0980'..'\u09FF' }

        if (isTtsReady && tts != null) {
            try {
                tts?.stop()

                if (isBengali) {
                    val bnResult = tts?.setLanguage(Locale("bn", "BD"))
                    if (bnResult == TextToSpeech.LANG_MISSING_DATA || bnResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        val bnResult2 = tts?.setLanguage(Locale("bn"))
                        if (bnResult2 == TextToSpeech.LANG_MISSING_DATA || bnResult2 == TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts?.setLanguage(Locale.getDefault())
                        }
                    }
                } else {
                    tts?.setLanguage(Locale.US)
                }

                tts?.setPitch(persona.pitch)
                tts?.setSpeechRate(persona.speechRate)

                val params = Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "maya_${System.currentTimeMillis()}")
                }
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "maya_speech")
            } catch (e: Exception) {
                Log.e(TAG, "TTS speak exception: ${e.message}")
            }
        }

        // Automatic fallback completion timer in case TTS onDone is not invoked by the emulator
        val estimatedDuration = (text.length * 70L).coerceIn(2000L, 8000L)
        autoDoneRunnable = Runnable {
            _isSpeaking.value = false
            _audioWaveformLevel.value = 0.1f
        }
        mainHandler.postDelayed(autoDoneRunnable!!, estimatedDuration)
    }

    // "Interrupt Her" (Barge-in)
    fun interrupt() {
        autoDoneRunnable?.let { mainHandler.removeCallbacks(it) }
        try {
            tts?.stop()
        } catch (e: Exception) {
            // ignore
        }
        _isSpeaking.value = false
        _audioWaveformLevel.value = 0.1f
    }

    fun startListening() {
        if (_isSpeaking.value) {
            interrupt()
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            speechRecognizer?.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start speech recognizer", e)
            _isListening.value = false
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            // ignore
        }
        _isListening.value = false
    }

    fun release() {
        autoDoneRunnable?.let { mainHandler.removeCallbacks(it) }
        try {
            tts?.stop()
            tts?.shutdown()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // ignore
        }
    }
}
